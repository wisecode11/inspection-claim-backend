'use strict';

require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');

const PORT = Number(process.env.PORT) || 8000;
const MONGODB_URI = process.env.MONGODB_URI;

if (!process.env.JWT_SECRET) {
  throw new Error('JWT_SECRET is missing in .env');
}

async function connectMongo() {
  if (!MONGODB_URI) {
    throw new Error('MONGODB_URI is missing in .env');
  }

  await mongoose.connect(MONGODB_URI);
  console.log('MongoDB connected');
}

async function startServer() {
  await connectMongo();

  require('./models');

  const app = express();
  app.use(express.json());
  app.use('/api', require('./routes'));

  app.get('/', (_req, res) => {
    res.json({
      server: 'connected',
      port: PORT,
      mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    });
  });

  app.use(require('./middlewares/error.middleware'));

  app.listen(PORT, () => {
    console.log(`Server connected on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error.message);
  process.exit(1);
});
